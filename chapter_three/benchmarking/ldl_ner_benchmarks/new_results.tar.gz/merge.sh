#!/bin/sh

FILES=" _home_kyungtae_NIF_Benchmark_TestData_Magnus_dbpedia-spotlight-nif.ttl.results.ttl _home_kyungtae_NIF_Benchmark_TestData_Magnus_kore50-nif.ttl.results.ttl _home_kyungtae_NIF_Benchmark_TestData_Magnus_Reuters-128.ttl.results.ttl _home_kyungtae_NIF_Benchmark_TestData_Magnus_RSS-500.ttl.results.ttl _home_kyungtae_NIF_Benchmark_TestData_Martin_wikidump.ttl.results.ttl news-100_ricardo.ttl"

for i in $FILES 
do 
echo $i
FILENAME=$i".merged.nt"
FILENAMEFINAL=$i".merged.ttl"
echo "" > $FILENAME
rapper -g nif.cache.Schema.ttl >> $FILENAME
rapper -g nif.tests.Schema.ttl >> $FILENAME
rapper -g $i >> $FILENAME

rapper -i ntriples -o turtle $FILENAME > $FILENAMEFINAL
echo $FILENAMEFINAL
~/bin/mytools/apache-jena-current/bin/arq --file=/tmp/new_results/finderrors.sparql  --data="$FILENAMEFINAL" > $i"ERRORS_ONLY.ttl" 

done
